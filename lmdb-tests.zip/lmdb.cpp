#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <string>

#include "lmdb_tools.h"

int main(int argc, char * argv[])
{
	//test simple write/read/check
    putdb("testkey", "value");
    putdb("testkey", "value1");
	
	char* val = getdb("testkey");
    printf("testkey %s\n", val);
	free(val);
	
	int status = checkdb("testkey");
	printf("status %i\n", status);
	
	status = checkdb("falsekey");
	printf("status %i\n", status);
	
	//test VL insersion
	std::vector<std::vector<std::string> > VL1_data;
	for(int x=0; x<3; x++)
	{
		std::vector<std::string> field;
		for(int y=0; y<3; y++)
		{
			std::string value = "toto_"+to_string(y);
			field.push_back(value);
		}
		VL1_data.push_back(field);
	}
	
	insert_VL("test_vl_1", VL1_data);
	
	//test VL access
	std::vector<std::vector<std::string> > VL1_data_loaded;
	status = get_VL("test_vl_1", VL1_data_loaded);
	
	for(int x=0; x<VL1_data_loaded.size(); x++)
	{
		std::vector<std::string> field = VL1_data_loaded[x];
		for (int y=0; y<field.size(); y++)
		{
			std::cout<<"loaded data: "<<field[y]<<std::endl;
		}
	}
	
    return 0;
}
