#include <string>
#include <vector>
#include <iostream>
#include <sstream>

#include "lmdb_c_tools.h"

void insert_VL(std::string VL_id, std::vector<std::vector<std::string> > data);
/* returns 1 if the VL exists, 0 if nothing was found*/
int get_VL(std::string VL_id, std::vector<std::vector<std::string> >& data);
std::string get_field_counter_key(std::string VL_id, int field_id);
std::string create_content_key(std::string VL_id, int field_id, int content_id);
template <typename T> std::string to_string(T value);
