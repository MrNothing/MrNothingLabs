#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lmdb.h"

#define BUF_SIZE 1024
#define CACHE_SIZE 1UL * 1024UL * 1024UL * 1024UL //1gb

#define E(expr) CHECK((rc = (expr)) == MDB_SUCCESS, #expr)
#define CHECK(test, msg) ((test) ? (void)0 : ((void)fprintf(stderr, \
    "%s:%d: %s: %s\n", __FILE__, __LINE__, msg, mdb_strerror(rc)), abort()))

/* Must create somedb folder first */
#define DBDIR "./somedb"


/* Put the key to db */
int putdb(char *, char *);

/* Get the key from db */
char* getdb(char *);

/* Check if key exists: 1=yes 0=no*/
int checkdb(char *);