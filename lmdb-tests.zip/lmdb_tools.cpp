#include "lmdb_tools.h"


//compilator issue fix
template <typename T> std::string to_string(T value)
{
	//create an output string stream
	std::ostringstream os ;

	//throw the value into the string stream
	os << value ;

	//convert the string stream into a string and return
	return os.str() ;
}

void insert_VL(std::string VL_id, std::vector<std::vector<std::string> > data)
{
	for(int x=0; x<data.size(); x++)
	{
		std::vector<std::string> field = data[x];
		for (int y=0; y<field.size(); y++)
		{
			std::string key = create_content_key(VL_id, x, y);
			std::string value = field[y];
			std::cout<<key<<"="<<value<<std::endl;
			putdb((char*)key.c_str(), (char*)value.c_str());
		}
	}
}

int get_VL(std::string VL_id, std::vector<std::vector<std::string> >& data)
{
	int field_counter = 0;
	int field_status = checkdb((char*)create_content_key(VL_id, 0, 0).c_str());
	
	if(field_status==0)
	{
		return 0;
	}
	
	while(field_status==1)
	{
		int value_counter = 0;
		int status = 1;
		
		std::vector<std::string> tmp_field;
		data.push_back(tmp_field);
		
		while((status=checkdb((char*)create_content_key(VL_id, field_counter, value_counter).c_str()))==1)
		{	
			std::cout<<"getting: "<<create_content_key(VL_id, field_counter, value_counter)<<std::endl;
			char* value = getdb((char*)create_content_key(VL_id, field_counter, value_counter).c_str());
			data[field_counter].push_back(std::string(value));
			free(value);
	
			//next value
			value_counter++;
		}
		
		//next field...
		field_status = checkdb((char*)create_content_key(VL_id, field_counter, 0).c_str());
		field_counter++;
	}
	
	return 1;
}

std::string get_field_counter_key(std::string VL_id, int field_id)
{
	std::string separator = "_";
	std::string id= VL_id+separator+to_string(field_id)+std::string("_counter");
	return id;
}

std::string create_content_key(std::string VL_id, int field_id, int content_id)
{
	std::string separator = "_";
	std::string id= VL_id+separator+to_string(field_id)+separator+to_string(content_id);
	return id;
}
