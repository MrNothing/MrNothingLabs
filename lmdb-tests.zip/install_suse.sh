wget http://ftp.gwdg.de/pub/opensuse/distribution/leap/42.3/repo/oss/suse/x86_64/liblmdb-0_9_14-0.9.14-7.3.x86_64.rpm
sudo rpm -i liblmdb-0_9_14-0.9.14-7.3.x86_64.rpm
rm liblmdb-0_9_14-0.9.14-7.3.x86_64.rpm
wget -P /usr/include https://raw.githubusercontent.com/rvagg/lmdb/master/deps/liblmdb-20130601/lmdb.h