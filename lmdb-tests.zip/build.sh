gcc test.c -llmdb -g -o  test
g++ lmdb.cpp lmdb_tools.cpp lmdb_c_tools.c -llmdb -g -o lmdb
